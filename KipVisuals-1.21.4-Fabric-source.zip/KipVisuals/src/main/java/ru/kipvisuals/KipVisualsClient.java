package ru.kipvisuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.io.*;
import java.nio.file.*;
import java.util.HashMap;
import java.util.Map;

public class KipVisualsClient implements ClientModInitializer {
    public static boolean hitSound = true;
    public static boolean hitEffect = true;
    public static boolean customHitboxes = false;
    public static double hitboxScale = 1.0;

    private static KeyBinding openMenu;
    private static KeyBinding increase;
    private static KeyBinding decrease;
    private static final Map<Integer, Integer> LAST_HURT = new HashMap<>();
    private static final Path CONFIG = MinecraftClient.getInstance().runDirectory.toPath()
            .resolve("config").resolve("kipvisuals.properties");

    @Override
    public void onInitializeClient() {
        loadConfig();
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kipvisuals.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.kipvisuals"));
        increase = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kipvisuals.increase", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UP,
                "category.kipvisuals"));
        decrease = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kipvisuals.decrease", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_DOWN,
                "category.kipvisuals"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new KipVisualsScreen());
                else if (client.currentScreen instanceof KipVisualsScreen) client.setScreen(null);
            }
            while (increase.wasPressed()) changeHitbox(0.05);
            while (decrease.wasPressed()) changeHitbox(-0.05);
            checkHits(client);
        });
    }

    public static void changeHitbox(double amount) {
        hitboxScale = Math.max(1.0, Math.min(3.0, Math.round((hitboxScale + amount) * 100.0) / 100.0));
        customHitboxes = hitboxScale > 1.0;
        saveConfig();
    }

    private static void checkHits(MinecraftClient client) {
        if (client.world == null || client.player == null) return;
        for (PlayerEntity target : client.world.getPlayers()) {
            if (target == client.player) continue;
            int hurt = target.hurtTime;
            int old = LAST_HURT.getOrDefault(target.getId(), 0);
            if (hurt > 0 && old == 0) {
                if (hitSound) client.world.playSound(null, target.getX(), target.getY(), target.getZ(),
                        SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, SoundCategory.PLAYERS, 0.7f, 1.15f);
                if (hitEffect) {
                    for (int i = 0; i < 8; i++) {
                        client.world.addParticle(ParticleTypes.CRIT,
                                target.getX() + (client.world.random.nextDouble() - 0.5) * 0.6,
                                target.getY() + 0.8 + client.world.random.nextDouble() * 0.8,
                                target.getZ() + (client.world.random.nextDouble() - 0.5) * 0.6,
                                0, 0.08, 0);
                    }
                }
            }
            LAST_HURT.put(target.getId(), hurt);
        }
    }

    public static void saveConfig() {
        try {
            Files.createDirectories(CONFIG.getParent());
            Properties p = new Properties();
            p.setProperty("hitSound", Boolean.toString(hitSound));
            p.setProperty("hitEffect", Boolean.toString(hitEffect));
            p.setProperty("customHitboxes", Boolean.toString(customHitboxes));
            p.setProperty("hitboxScale", Double.toString(hitboxScale));
            try (OutputStream out = Files.newOutputStream(CONFIG)) { p.store(out, "Kip Visuals"); }
        } catch (IOException e) { e.printStackTrace(); }
    }

    private static void loadConfig() {
        if (!Files.exists(CONFIG)) return;
        try (InputStream in = Files.newInputStream(CONFIG)) {
            Properties p = new Properties(); p.load(in);
            hitSound = Boolean.parseBoolean(p.getProperty("hitSound", "true"));
            hitEffect = Boolean.parseBoolean(p.getProperty("hitEffect", "true"));
            customHitboxes = Boolean.parseBoolean(p.getProperty("customHitboxes", "false"));
            hitboxScale = Math.max(1.0, Math.min(3.0, Double.parseDouble(p.getProperty("hitboxScale", "1.0"))));
        } catch (Exception e) { e.printStackTrace(); }
    }
}
