package ru.kipvisuals.mixin;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.kipvisuals.KipVisualsClient;

@Mixin(Entity.class)
public abstract class EntityHitboxMixin {
    @Inject(method = "getBoundingBox", at = @At("RETURN"), cancellable = true)
    private void kipvisuals$expandPlayerBox(CallbackInfoReturnable<Box> cir) {
        if (!KipVisualsClient.customHitboxes || KipVisualsClient.hitboxScale <= 1.0) return;
        Entity self = (Entity)(Object)this;
        if (!(self instanceof PlayerEntity) || !self.getWorld().isClient) return;
        Box box = cir.getReturnValue();
        double scale = KipVisualsClient.hitboxScale;
        double cx = (box.minX + box.maxX) * 0.5;
        double cz = (box.minZ + box.maxZ) * 0.5;
        double cy = (box.minY + box.maxY) * 0.5;
        double hx = (box.maxX - box.minX) * 0.5 * scale;
        double hy = (box.maxY - box.minY) * 0.5 * scale;
        double hz = (box.maxZ - box.minZ) * 0.5 * scale;
        cir.setReturnValue(new Box(cx - hx, cy - hy, cz - hz, cx + hx, cy + hy, cz + hz));
    }
}
