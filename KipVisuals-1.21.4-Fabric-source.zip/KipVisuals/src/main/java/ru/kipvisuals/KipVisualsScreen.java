package ru.kipvisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class KipVisualsScreen extends Screen {
    public KipVisualsScreen() { super(Text.literal("Kip Visuals")); }

    @Override
    protected void init() {
        int cx = width / 2;
        int y = height / 2 - 64;
        int w = 190;
        addDrawableChild(toggle("Hit Sound", () -> KipVisualsClient.hitSound,
                v -> KipVisualsClient.hitSound = v, cx - w/2, y));
        addDrawableChild(toggle("Hit Effect", () -> KipVisualsClient.hitEffect,
                v -> KipVisualsClient.hitEffect = v, cx - w/2, y + 25));
        addDrawableChild(toggle("Custom Hitboxes", () -> KipVisualsClient.customHitboxes,
                v -> { KipVisualsClient.customHitboxes = v; if (!v) KipVisualsClient.hitboxScale = 1.0; else if (KipVisualsClient.hitboxScale <= 1.0) KipVisualsClient.hitboxScale = 1.2; },
                cx - w/2, y + 50));
        addDrawableChild(ButtonWidget.builder(Text.literal("−"), b -> KipVisualsClient.changeHitbox(-0.05))
                .dimensions(cx - 95, y + 82, 42, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> KipVisualsClient.changeHitbox(0.05))
                .dimensions(cx + 53, y + 82, 42, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Закрыть"), b -> close())
                .dimensions(cx - 45, y + 116, 90, 20).build());
    }

    private interface Getter { boolean get(); }
    private interface Setter { void set(boolean value); }

    private ButtonWidget toggle(String name, Getter getter, Setter setter, int x, int y) {
        return ButtonWidget.builder(Text.literal(name + ": " + (getter.get() ? "ON" : "OFF")), b -> {
            setter.set(!getter.get());
            KipVisualsClient.saveConfig();
            b.setMessage(Text.literal(name + ": " + (getter.get() ? "ON" : "OFF")));
        }).dimensions(x, y, 190, 20).build();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Transparent background: deliberately do not call renderBackground().
        int cx = width / 2;
        int top = height / 2 - 94;
        context.fill(cx - 112, top, cx + 112, top + 226, 0xB9000000);
        context.fill(cx - 112, top, cx + 112, top + 1, 0xFFFFFFFF);
        context.fill(cx - 112, top + 225, cx + 112, top + 226, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, "KIP VISUALS", cx, top + 9, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                "Hitbox size: " + String.format(java.util.Locale.ROOT, "%.2f", KipVisualsClient.hitboxScale) + "x",
                cx, top + 154, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, "↑ / ↓  change size", cx, top + 169, 0xFFCCCCCC);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // No blur and no dark overlay.
    }

    @Override public boolean shouldPause() { return false; }
}
